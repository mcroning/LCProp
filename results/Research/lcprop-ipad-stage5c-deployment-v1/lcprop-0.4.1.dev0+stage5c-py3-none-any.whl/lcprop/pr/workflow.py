"""Minimal headless time-dependent photorefractive propagation workflow."""

from __future__ import annotations

from dataclasses import replace
from time import perf_counter
from typing import Any, Callable

import numpy as np

from lcprop.core.backend import asnumpy, get_backend
from lcprop.core.execution import CancellationToken, RunProgress
from lcprop.core.grid import make_grid
from lcprop.optics.launch import OpticalLaunchContext, build_launch, normalized_power
from lcprop.optics.splitstep import (
    advance_prepared_response,
    hop_linear_inplace,
    apply_response_screen_inplace,
    scalar_angular_spectrum_kernel,
    total_intensity,
)
from lcprop.pr.live_results import PRLivePreviewPolicy, reduced_pr_live_snapshot
from lcprop.pr.checkpoint import (
    PRTimeDependentCheckpoint,
    validate_pr_checkpoint,
    validate_pr_continuation,
)
from lcprop.pr.evolution import (
    euler_step,
    legacy_conservative_timestep_limit,
    paper_conservative_timestep_limit,
    semi_implicit_trapezoidal_step,
    validate_timestep,
)
from lcprop.pr.optical_response import half_step_response_from_E, delta_n_from_E
from lcprop.optics.boundaries import transverse_boundary_mask, apply_transverse_boundary_inplace
from lcprop.pr.scattering import (
    canonical_scattering_phase_increment,
    canonical_scattering_provenance,
    canonical_slab_range,
)

from lcprop.pr.illumination import resolve_material_illumination, PhysicalIlluminationReference
from lcprop.pr.source import (
    channel_peak_intensity_reference,
    pr_driving_intensity,
)
from lcprop.pr.specs import (
    PRRunRequest,
    PRRunResult,
    PR_EULER_INTEGRATOR,
    PR_SEMI_IMPLICIT_INTEGRATOR,
    PR_TIMEDEPENDENT_WORKFLOW,
    PR_TD_PUBLISHED_COUPLING,
    validate_pr_timedependent_configuration,
)
from lcprop.pr.visualization import (
    TD_MOVIE_MAX_FRAMES,
    downsample_td_movie_frame,
    encode_td_preview_movie,
)
from lcprop.optics.launch_configuration import (
    LaunchConfiguration,
    reject_prepared_launch_conflict,
)


ProgressCallback = Callable[[RunProgress], None]


class _PRCancellationRequested(Exception):
    """Internal cooperative unwind from discardable PR TD work."""

    def __init__(self, stage: str):
        super().__init__(stage)
        self.stage = stage


def _raise_if_cancelled(
    cancellation_token: CancellationToken | None,
    *,
    stage: str,
) -> None:
    if cancellation_token is not None and cancellation_token.is_cancelled():
        raise _PRCancellationRequested(stage)


def _validate_canonical_scattering_for_grid(scattering, *, grid, z_length_um):
    """Validate that every TD z interval is a union of canonical slabs."""

    if scattering is None:
        return
    canonical_slab_range(
        scattering,
        z_start_um=0.0,
        dz_um=float(grid.dz_um),
        z_length_um=float(z_length_um),
    )


def _canonical_scattering_phase_for_slice(
    scattering,
    *,
    z_index: int,
    grid,
    z_length_um: float,
    xp,
):
    """Construct the canonical phase increment for one physical TD slice."""

    return canonical_scattering_phase_increment(
        scattering,
        z_start_um=float(z_index) * float(grid.dz_um),
        dz_um=float(grid.dz_um),
        z_length_um=float(z_length_um),
        Nx=grid.Nx,
        Ny=grid.Ny,
        x_aperture_um=float(grid.spec.x_aperture_um),
        y_aperture_um=float(grid.spec.y_aperture_um),
        real_dtype=grid.real_dtype,
        xp=xp,
    )


def _apply_canonical_scattering_after_slice(
    A,
    *,
    scattering,
    z_index: int,
    grid,
    z_length_um: float,
    xp,
    phase=None,
) -> None:
    """Apply one canonical phase increment after an accepted optical slice."""

    if scattering is None:
        return
    if phase is None:
        phase = _canonical_scattering_phase_for_slice(
            scattering,
            z_index=z_index,
            grid=grid,
            z_length_um=z_length_um,
            xp=xp,
        )
    A *= xp.exp(1j * phase)[None, :, :]


def _canonical_scattering_phase_stack(
    scattering,
    *,
    grid,
    z_length_um: float,
    xp,
):
    """Precompute deterministic per-interval scattering phases for replay."""

    if scattering is None:
        return None
    phases = xp.empty((grid.Nz, grid.Nx, grid.Ny), dtype=grid.real_dtype)
    for z_index in range(grid.Nz):
        phases[z_index] = _canonical_scattering_phase_for_slice(
            scattering,
            z_index=z_index,
            grid=grid,
            z_length_um=z_length_um,
            xp=xp,
        )
    return phases


def _initial_fields(request: PRRunRequest, *, launch, grid, complex_dtype, real_dtype):
    xp = grid.xp
    if request.initial_A is None:
        A0 = launch.A0.copy()
    else:
        A0 = xp.asarray(request.initial_A, dtype=complex_dtype).copy()
        if A0.shape != launch.A0.shape:
            raise ValueError(
                f"initial_A shape {A0.shape} does not match {launch.A0.shape}"
            )

    E_shape = (grid.Nz, grid.Nx, grid.Ny)
    if request.initial_E is None:
        E0 = xp.zeros(E_shape, dtype=real_dtype)
    else:
        E0 = xp.asarray(request.initial_E, dtype=real_dtype).copy()
        if E0.shape != E_shape:
            raise ValueError(f"initial_E shape {E0.shape} does not match {E_shape}")
    return A0, E0


def advance_pr_slice_with_midpoint_source(
    A_in,
    E_slice,
    *,
    kernel,
    optical_substeps: int,
    dz_um: float,
    wavelength_um: float,
    interaction_length_um: float,
    gain_length_product: float,
    peak_intensity_reference: float,
    background_intensity: float,
    coherence_groups,
    xp,
    optical_boundary=None,
    boundary_grid=None,
    _intensity_before=None,
    _return_exit_intensity: bool = False,
    _research_linear_hop=None,
    _research_real_window=None,
):
    """Advance one frozen-E PR slice and return its midpoint source.

    The input field is not modified. The returned source is the arithmetic
    mean of the normalized PR-driving intensities immediately before and
    after the prepared-response Strang slice, matching the time-dependent
    workflow's established material-source definition.
    """

    A_out, source, exit_intensity = (
        _advance_pr_slice_with_midpoint_source_and_exit_intensity(
            A_in,
            E_slice,
            kernel=kernel,
            optical_substeps=optical_substeps,
            dz_um=dz_um,
            wavelength_um=wavelength_um,
            interaction_length_um=interaction_length_um,
            gain_length_product=gain_length_product,
            peak_intensity_reference=peak_intensity_reference,
            background_intensity=background_intensity,
            coherence_groups=coherence_groups,
            xp=xp,
            optical_boundary=optical_boundary,
            boundary_grid=boundary_grid,
            intensity_before=_intensity_before,
            _research_linear_hop=_research_linear_hop,
            _research_real_window=_research_real_window,
        )
    )
    if _return_exit_intensity:
        return A_out, source, exit_intensity
    return A_out, source


def _advance_pr_slice_with_midpoint_source_and_exit_intensity(
    A_in,
    E_slice,
    *,
    kernel,
    optical_substeps: int,
    dz_um: float,
    wavelength_um: float,
    interaction_length_um: float,
    gain_length_product: float,
    peak_intensity_reference: float,
    background_intensity: float,
    coherence_groups,
    xp,
    optical_boundary=None,
    boundary_grid=None,
    intensity_before=None,
    _research_linear_hop=None,
    _research_real_window=None,
):
    """Advance one frozen-E slice and also return its exit intensity."""

    resolved_substeps = int(optical_substeps)
    if resolved_substeps < 1:
        raise ValueError("optical_substeps must be at least one")
    A_out = A_in.copy()
    if intensity_before is None:
        I_before = pr_driving_intensity(
            A_out,
            peak_intensity_reference=peak_intensity_reference,
            background_intensity=background_intensity,
            coherence_groups=coherence_groups,
            xp=xp,
        )
    else:
        I_before = intensity_before
    half_response = half_step_response_from_E(
        E_slice,
        dz_substep_um=float(dz_um) / resolved_substeps,
        wavelength_um=wavelength_um,
        interaction_length_um=interaction_length_um,
        gain_length_product=gain_length_product,
        xp=xp,
    )
    advance_prepared_response(
        A_out,
        kernel=kernel,
        half_step_response=half_response,
        Nsub=resolved_substeps,
        boundary=optical_boundary,
        boundary_grid=boundary_grid,
        propagation_distance_um=dz_um,
        xp=xp,
        _research_linear_hop=_research_linear_hop,
        _research_real_window=_research_real_window,
    )
    I_after = pr_driving_intensity(
        A_out,
        peak_intensity_reference=peak_intensity_reference,
        background_intensity=background_intensity,
        coherence_groups=coherence_groups,
        xp=xp,
    )
    return A_out, 0.5 * (I_before + I_after), I_after


def advance_pr_published_frozen_slice(
    A, E, *, request, grid, kernel, peak_reference, wavelength_um,
):
    """P -> arriving I -> frozen E phase; caller applies the canonical S.

    E belongs to one accepted/predictor temporal stage and is read-only here.
    Reuse the commissioned Static optical primitives, not its equilibrium
    material solve/residual gate. Linear subhops span exactly h; the full
    material phase and configured physical-cell boundary act once. No optical
    longitudinal volume, midpoint source or temporal update is constructed.
    """
    xp = grid.xp
    for _ in range(int(request.solver.optical_substeps)):
        hop_linear_inplace(A, kernel, xp=xp)
    intensity = pr_driving_intensity(
        A, peak_intensity_reference=peak_reference,
        background_intensity=request.material.background_intensity,
        coherence_groups=request.beams.coherence_groups, xp=xp,
    )
    dn = delta_n_from_E(
        E, gain_length_product=request.material.gain_length_product,
        interaction_length_um=request.grid.z_length_um,
        wavelength_um=wavelength_um,
    )
    phase = xp.exp(1j * (2 * np.pi / wavelength_um) * grid.dz_um * dn)
    apply_response_screen_inplace(A, phase, xp=xp)
    boundary = request.optical_boundary
    mask = transverse_boundary_mask(
        grid, boundary,
        propagation_distance_um=(grid.dz_um if boundary.mode == "sponge" else None),
    )
    apply_transverse_boundary_inplace(A, mask)
    return A, intensity


def _optical_pass(
    A0,
    E,
    *,
    request: PRRunRequest,
    grid,
    kernel,
    peak_reference: float,
    wavelength_um: float,
    cancellation_token: CancellationToken | None = None,
    cancellation_stage: str = "optical_z_march",
):
    xp = grid.xp
    A = A0.copy()
    source_stack = xp.empty(E.shape, dtype=grid.real_dtype)
    groups = request.beams.coherence_groups
    intensity_before = None

    for k in range(grid.Nz):
        _raise_if_cancelled(
            cancellation_token,
            stage=cancellation_stage,
        )
        if request.optical_coupling == PR_TD_PUBLISHED_COUPLING:
            A, source_stack[k] = advance_pr_published_frozen_slice(
                A, E[k], request=request, grid=grid, kernel=kernel,
                peak_reference=peak_reference, wavelength_um=wavelength_um,
            )
        else:
            A, source_stack[k], intensity_before = (
                advance_pr_slice_with_midpoint_source(
                    A,
                    E[k],
                    kernel=kernel,
                    optical_substeps=request.solver.optical_substeps,
                    dz_um=grid.dz_um,
                    wavelength_um=wavelength_um,
                    interaction_length_um=request.grid.z_length_um,
                    gain_length_product=request.material.gain_length_product,
                    peak_intensity_reference=peak_reference,
                    background_intensity=request.material.background_intensity,
                    coherence_groups=groups,
                    xp=xp,
                    optical_boundary=request.optical_boundary,
                    boundary_grid=grid,
                    _intensity_before=intensity_before,
                    _return_exit_intensity=True,
                )
            )
        _apply_canonical_scattering_after_slice(
            A,
            scattering=request.scattering,
            z_index=k,
            grid=grid,
            z_length_um=request.grid.z_length_um,
            xp=xp,
        )
    return A, source_stack


def run_pr_timedependent(
    request: PRRunRequest,
    *,
    cancellation_token: CancellationToken | None = None,
    progress_callback: ProgressCallback | None = None,
    live_preview_policy: PRLivePreviewPolicy | None = None,
    _completed_steps_offset: int = 0,
    _requested_steps_total: int | None = None,
    _cumulative_start_time: float = 0.0,
    _checkpoint_request: PRRunRequest | None = None,
    _origin_E: Any | None = None,
) -> PRRunResult:
    """Run the frozen-state PR workflow with optional execution controls.

    Cancellation is observed within discardable optical and material
    substages as well as between complete material-time updates.  A candidate
    material state is committed only after every required substage succeeds.
    Progress snapshots contain the latest accepted ``E`` state and a detached
    optical replay through that state; neither observation changes subsequent
    physics.
    """

    started_at = perf_counter()
    if live_preview_policy is not None and not isinstance(live_preview_policy, PRLivePreviewPolicy):
        raise TypeError("live_preview_policy must be a PRLivePreviewPolicy")

    request.grid.validate()
    request.beams.validate()
    request.material.validate()
    if request.material.normalization_identity != "pr_channel_peak_reference_v1" and request.initial_A is not None:
        raise ValueError("physical TD prepared initial_A requires an explicit physical scale; use the physical launch configuration")
    request.solver.validate()
    request.backend.validate()
    validate_pr_timedependent_configuration(request)
    request.optical_boundary.validate()
    LaunchConfiguration(request.beams, request.launch_elements)
    if _checkpoint_request is None:
        reject_prepared_launch_conflict(
            request.initial_A,
            request.launch_elements,
        )
    if request.scattering is not None:
        request.scattering.validate()

    wavelengths = tuple(
        float(channel.wavelength_um) for channel in request.beams.channels
    )
    if any(value != wavelengths[0] for value in wavelengths[1:]):
        raise ValueError("minimal PR workflow requires one shared wavelength")

    backend = get_backend(request.backend)
    grid = make_grid(
        request.grid,
        xp=backend.xp,
        real_dtype=backend.real_dtype,
    )
    _validate_canonical_scattering_for_grid(
        request.scattering,
        grid=grid,
        z_length_um=request.grid.z_length_um,
    )
    if (request.material.normalization_identity != "pr_channel_peak_reference_v1"
            and sum(ch.power_mW for ch in request.beams.channels) == 0):
        from lcprop.pr.reduced_continuation import physical_launch
        launch = physical_launch(request, grid, backend.complex_dtype)
    else:
        launch = build_launch(
            request.beams,
            grid,
            complex_dtype=backend.complex_dtype,
            launch_elements=request.launch_elements,
            context=OpticalLaunchContext(
                grid=grid,
                n_ref=float(request.material.refractive_index),
                interaction_length_um=float(request.grid.z_length_um),
            ),
        )
    A0, E = _initial_fields(
        request,
        launch=launch,
        grid=grid,
        complex_dtype=backend.complex_dtype,
        real_dtype=backend.real_dtype,
    )
    if _origin_E is None:
        E_initial = E.copy()
    else:
        E_initial = grid.xp.asarray(
            _origin_E,
            dtype=grid.real_dtype,
        ).copy()
        if E_initial.shape != E.shape:
            raise ValueError(
                "origin E shape does not match continuation state shape"
            )
    input_request = request
    source_reference, runtime_material = resolve_material_illumination(
        request.material, A0,
        grid=grid, optical_scale_W_cm2=launch.physical_total_power_mW * 1e5,
        coherence_groups=request.beams.coherence_groups, xp=grid.xp)
    request = replace(request, material=runtime_material)
    peak_reference = source_reference
    timestep_limit = validate_timestep(
        request.solver.dt_normalized, grid, request.material,
        integrator=request.solver.integrator,
    )

    wavelength_um = wavelengths[0]
    dz_substep = grid.dz_um / int(request.solver.optical_substeps)
    kernel = scalar_angular_spectrum_kernel(
        grid.fxy2_um,
        dz=dz_substep,
        wavelength=wavelength_um,
        n_ref=request.material.refractive_index,
        xp=grid.xp,
        complex_dtype=backend.complex_dtype,
    )

    segment_total_steps = int(request.solver.Nt)
    requested_steps = (
        int(_completed_steps_offset) + segment_total_steps
        if _requested_steps_total is None
        else int(_requested_steps_total)
    )
    completed_steps = int(_completed_steps_offset)
    checkpoint_request = _checkpoint_request or replace(
        input_request,
        initial_A=None,
        initial_E=None,
    )
    cancelled = False
    cancellation_stage: str | None = None
    cancellation_observed_at: float | None = None
    source_stack = grid.xp.empty(E.shape, dtype=grid.real_dtype)
    accepted_observation: tuple[int, Any, Any] | None = None
    last_preview_step = None
    last_preview_at = float("-inf")
    td_scalar_history: list[dict[str, float]] = []
    movie_indices = set(np.unique(np.rint(np.linspace(
        completed_steps,
        requested_steps,
        min(segment_total_steps + 1, TD_MOVIE_MAX_FRAMES),
    )).astype(int)).tolist())
    from lcprop.pr.td_movie_products import AcceptedMovieProducts
    extra_movies = AcceptedMovieProducts()
    movie_frames: list[np.ndarray] = []
    material_movie_frames: list[np.ndarray] = []
    movie_frame_indices: list[int] = []
    movie_times: list[float] = []

    def retain_movie_frame(index: int, optical_field, accepted_source) -> None:
        if progress_callback is None or index not in movie_indices:
            return
        if movie_frame_indices and movie_frame_indices[-1] == int(index):
            return
        intensity = total_intensity(
            optical_field,
            coherence_groups=launch.coherence_groups,
            xp=grid.xp,
        )
        movie_frames.append(
            downsample_td_movie_frame(intensity, xp=grid.xp, asnumpy=asnumpy)
        )
        material_movie_frames.append(downsample_td_movie_frame(
            E[grid.Nz // 2], xp=grid.xp, asnumpy=asnumpy))
        extra_movies.append(optical_field, accepted_source, grid=grid, request=request,
                            reference=peak_reference, groups=launch.coherence_groups, asnumpy=asnumpy)
        movie_frame_indices.append(int(index))
        movie_times.append(
            float(_cumulative_start_time)
            + (int(index) - int(_completed_steps_offset))
            * float(request.solver.dt_normalized)
        )

    def source_intensity_for_state(candidate_E):
        nonlocal accepted_observation
        candidate_A, candidate_source = _optical_pass(
            A0,
            candidate_E,
            request=request,
            grid=grid,
            kernel=kernel,
            peak_reference=peak_reference,
            wavelength_um=wavelength_um,
            cancellation_token=cancellation_token,
            cancellation_stage="material_source_optical_z_march",
        )
        if candidate_E is E:
            accepted_observation = (
                completed_steps,
                candidate_A,
                candidate_source,
            )
            retain_movie_frame(completed_steps, candidate_A, candidate_source)
        return candidate_source

    for step_index in range(segment_total_steps):
        if cancellation_token is not None and cancellation_token.is_cancelled():
            cancelled = True
            cancellation_stage = "material_step_boundary"
            cancellation_observed_at = perf_counter()
            break

        try:
            if request.solver.integrator == PR_EULER_INTEGRATOR:
                candidate_source_stack = source_intensity_for_state(E)
                _raise_if_cancelled(
                    cancellation_token,
                    stage="euler_after_source",
                )
                candidate_E = euler_step(
                    E,
                    candidate_source_stack,
                    dt_normalized=request.solver.dt_normalized,
                    applied_field=request.material.applied_field,
                    background_intensity=request.material.background_intensity,
                    dx_normalized=(
                        request.material.characteristic_wavenumber_per_um
                        * grid.dx_um
                    ),
                    xp=grid.xp,
                )
                _raise_if_cancelled(
                    cancellation_token,
                    stage="euler_after_material_update",
                )
            elif request.solver.integrator == PR_SEMI_IMPLICIT_INTEGRATOR:
                candidate_E = semi_implicit_trapezoidal_step(
                    E,
                    source_intensity_for_state,
                    dt_normalized=request.solver.dt_normalized,
                    applied_field=request.material.applied_field,
                    background_intensity=request.material.background_intensity,
                    dx_normalized=(
                        request.material.characteristic_wavenumber_per_um
                        * grid.dx_um
                    ),
                    xp=grid.xp,
                    cancellation_check=lambda: _raise_if_cancelled(
                        cancellation_token,
                        stage="semi_implicit_predictor_corrector",
                    ),
                )
            else:  # guarded by PRSolverOptions.validate()
                raise ValueError(
                    f"unknown PR integrator: {request.solver.integrator}"
                )

            candidate_observation = None
            if progress_callback is not None:
                candidate_observation = _optical_pass(
                    A0,
                    candidate_E,
                    request=request,
                    grid=grid,
                    kernel=kernel,
                    peak_reference=peak_reference,
                    wavelength_um=wavelength_um,
                    cancellation_token=cancellation_token,
                    cancellation_stage="progress_optical_z_march",
                )
                _raise_if_cancelled(
                    cancellation_token,
                    stage="after_progress_optical_replay",
                )
        except _PRCancellationRequested as exc:
            cancelled = True
            cancellation_stage = exc.stage
            cancellation_observed_at = perf_counter()
            break

        material_change_rms = float(asnumpy(grid.xp.sqrt(
            grid.xp.mean((candidate_E - E) * (candidate_E - E))
        )))
        E = candidate_E
        if request.solver.integrator == PR_EULER_INTEGRATOR:
            source_stack = candidate_source_stack
        segment_completed_steps = step_index + 1
        completed_steps = (
            int(_completed_steps_offset) + segment_completed_steps
        )
        scalar_row = {
            "material_time_normalized": (
                float(_cumulative_start_time)
                + segment_completed_steps * float(request.solver.dt_normalized)
            ),
            "material_state_change_rms": material_change_rms,
        }
        carrier = 1.0 + (
            grid.xp.roll(E, -1, axis=-2)
            - grid.xp.roll(E, 1, axis=-2)
        ) / (
            2.0
            * request.material.characteristic_wavenumber_per_um
            * grid.dx_um
        )
        scalar_row["minimum_carrier_density"] = float(
            asnumpy(grid.xp.min(carrier))
        )
        td_scalar_history.append(scalar_row)

        if progress_callback is not None:
            assert candidate_observation is not None
            A_display, display_source_stack = candidate_observation
            accepted_observation = (
                completed_steps,
                A_display,
                display_source_stack,
            )
            segment_elapsed_time = (
                segment_completed_steps
                * float(request.solver.dt_normalized)
            )
            material_time = (
                float(_cumulative_start_time) + segment_elapsed_time
            )
            if live_preview_policy is None:
                field_state = {
                    "A_initial": np.asarray(asnumpy(A0)).copy(),
                    "A_current": np.asarray(asnumpy(A_display)).copy(),
                    "E_initial": np.asarray(asnumpy(E_initial)).copy(),
                    "E_current": np.asarray(asnumpy(E)).copy(),
                    "source_intensity_stack": np.asarray(
                        asnumpy(display_source_stack)
                    ).copy(),
                    "grid_summary": grid.summary(),
                    "launch_summary": launch.summary(),
                    "material_time_normalized": material_time,
                }
            else:
                now = perf_counter()
                due = (last_preview_step is None
                       or segment_completed_steps == segment_total_steps
                       or now - last_preview_at >= live_preview_policy.interval_seconds)
                field_state = None
                if due:
                    field_state = reduced_pr_live_snapshot(
                        E=E, A=A_display, source=display_source_stack, grid=grid,
                        groups=launch.coherence_groups, peak_reference=(0.0 if isinstance(peak_reference, PhysicalIlluminationReference) and peak_reference.optical_scale_W_cm2 == 0 else float(peak_reference)),
                        background=request.material.background_intensity,
                        policy=live_preview_policy, completed_steps=completed_steps,
                        segment_completed_steps=segment_completed_steps,
                        requested_steps=requested_steps, time_normalized=material_time,
                        scalar_values=scalar_row,
                        material_response=request.material_response.model,
                        wavelength_um=request.beams.channels[0].wavelength_um,
                        refractive_index=request.material.refractive_index,
                    )
                    last_preview_step, last_preview_at = completed_steps, now
            progress_callback(
                RunProgress(
                    workflow=PR_TIMEDEPENDENT_WORKFLOW,
                    status="running",
                    completed_units=completed_steps,
                    total_units=requested_steps,
                    current_coordinate=material_time,
                    coordinate_name="material_time",
                    coordinate_unit="normalized",
                    elapsed_wall_time=perf_counter() - started_at,
                    latest_field_state=field_state,
                    checkpoint_available=True,
                    message="PR material-time step completed",
                    completed_step=completed_steps,
                    total_steps=requested_steps,
                    current_time=material_time,
                    prior_completed_steps=int(_completed_steps_offset),
                    segment_completed_steps=segment_completed_steps,
                    segment_total_steps=segment_total_steps,
                    cumulative_completed_steps=completed_steps,
                    segment_start_time=float(_cumulative_start_time),
                    segment_elapsed_time=segment_elapsed_time,
                    cumulative_time=material_time,
                )
            )

            if live_preview_policy is not None and field_state is not None:
                last_preview_at = perf_counter()

    if (live_preview_policy is not None and progress_callback is not None
            and completed_steps > int(_completed_steps_offset)
            and last_preview_step != completed_steps
            and accepted_observation is not None
            and accepted_observation[0] == completed_steps):
        _, display_A, display_source = accepted_observation
        snapshot = reduced_pr_live_snapshot(
            E=E, A=display_A, source=display_source, grid=grid,
            groups=launch.coherence_groups, peak_reference=(0.0 if isinstance(peak_reference, PhysicalIlluminationReference) and peak_reference.optical_scale_W_cm2 == 0 else float(peak_reference)),
            background=request.material.background_intensity,
            policy=live_preview_policy, completed_steps=completed_steps,
            segment_completed_steps=segment_completed_steps,
            requested_steps=requested_steps, time_normalized=material_time,
            scalar_values=scalar_row, material_response=request.material_response.model,
            wavelength_um=request.beams.channels[0].wavelength_um,
            refractive_index=request.material.refractive_index,
        )
        progress_callback(RunProgress(
            workflow=PR_TIMEDEPENDENT_WORKFLOW, status="running",
            completed_units=completed_steps, total_units=requested_steps,
            current_coordinate=material_time, coordinate_name="material_time",
            coordinate_unit="normalized", elapsed_wall_time=perf_counter()-started_at,
            latest_field_state=snapshot, checkpoint_available=True,
            message="Last accepted PR state before cancellation",
            completed_step=completed_steps, total_steps=requested_steps,
            current_time=material_time, prior_completed_steps=int(_completed_steps_offset),
            segment_completed_steps=segment_completed_steps,
            segment_total_steps=segment_total_steps,
            cumulative_completed_steps=completed_steps,
            segment_start_time=float(_cumulative_start_time),
            segment_elapsed_time=segment_elapsed_time, cumulative_time=material_time,
        ))

    optical_observation = "complete_final_replay"
    if (
        cancelled
        and accepted_observation is not None
        and accepted_observation[0] == completed_steps
    ):
        _, A_final, source_stack = accepted_observation
        optical_observation = "cached_accepted_state_replay"
    elif cancelled:
        # No complete optical replay of the latest accepted E is available.
        # This can occur before the first material update or after one or more
        # accepted headless updates. Returning the launch boundary and its
        # finite driving intensity avoids both a misleading partial z-march
        # and an unconditional full replay after Stop. The checkpoint's
        # accepted E remains authoritative, and the diagnostics below make
        # this cancellation-only fallback explicit.
        A_final = A0.copy()
        launch_source = pr_driving_intensity(
            A0,
            peak_intensity_reference=peak_reference,
            background_intensity=request.material.background_intensity,
            coherence_groups=request.beams.coherence_groups,
            xp=grid.xp,
        )
        source_stack = grid.xp.broadcast_to(launch_source, E.shape)
        optical_observation = "unpropagated_launch_fallback"
    else:
        A_final, source_stack = _optical_pass(
            A0,
            E,
            request=request,
            grid=grid,
            kernel=kernel,
            peak_reference=peak_reference,
            wavelength_um=wavelength_um,
        )
    if optical_observation != "unpropagated_launch_fallback":
        retain_movie_frame(completed_steps, A_final, source_stack)

    status = "cancelled" if cancelled else "completed"
    A0_host = np.asarray(asnumpy(A0)).copy()
    E_initial_host = np.asarray(asnumpy(E_initial)).copy()
    E_final_host = np.asarray(asnumpy(E)).copy()
    if optical_observation == "unpropagated_launch_fallback":
        source_stack_host = np.asarray(asnumpy(source_stack))
    else:
        source_stack_host = np.asarray(asnumpy(source_stack)).copy()
    current_time = (
        float(_cumulative_start_time)
        + (completed_steps - int(_completed_steps_offset))
        * float(request.solver.dt_normalized)
    )
    checkpoint = PRTimeDependentCheckpoint(
        request=checkpoint_request,
        E_initial=E_initial_host.copy(),
        E_current=E_final_host.copy(),
        A0=A0_host.copy(),
        completed_steps=completed_steps,
        requested_steps=requested_steps,
        time_normalized=current_time,
        grid_summary=grid.summary(),
        E_dtype=str(E_final_host.dtype),
        A0_dtype=str(A0_host.dtype),
        status=status,
    )
    validate_pr_checkpoint(checkpoint)

    diagnostics = {
        "backend": backend.summary(),
        "characteristic_wavenumber_per_um": (
            request.material.characteristic_wavenumber_per_um
        ),
        "peak_intensity_reference": (0.0 if isinstance(peak_reference, PhysicalIlluminationReference) and peak_reference.optical_scale_W_cm2 == 0 else float(peak_reference)),
        **({"source_normalization": source_reference.metadata(), "normalization_identity": source_reference.identity} if isinstance(source_reference, PhysicalIlluminationReference) else {}),
        "integrator": request.solver.integrator,
        "optical_coupling": request.optical_coupling,
        "source_z_um": (
            ((np.arange(grid.Nz) + 1) * grid.dz_um).tolist()
            if request.optical_coupling == PR_TD_PUBLISHED_COUPLING else None
        ),
        "required_source_marches_per_material_step": (
            2 if request.solver.integrator == PR_SEMI_IMPLICIT_INTEGRATOR else 1
        ),
        "progress_optical_march_role": "observational_only",
        "cancellation_observed_stage": cancellation_stage,
        "cancellation_observed_wall_time": (
            None
            if cancellation_observed_at is None
            else cancellation_observed_at - started_at
        ),
        "final_optical_observation": optical_observation,
        "complete_optical_replay_available": (
            optical_observation != "unpropagated_launch_fallback"
        ),
        "optical_products_are_launch_fallback": (
            optical_observation == "unpropagated_launch_fallback"
        ),
        "run_status": status,
        "completed_material_steps": completed_steps,
        "conservative_dt_limit": timestep_limit,
        "paper_equation_15_dt_limit": (
            paper_conservative_timestep_limit(
                grid, request.material
            )
        ),
        "legacy_prprop3d_dt_limit": (
            legacy_conservative_timestep_limit(
                grid, request.material
            )
        ),
        "stepping_order": (
            f"{request.optical_coupling} pass, then synchronous E Euler update"
            if request.solver.integrator == PR_EULER_INTEGRATOR
            else (
                f"accepted/predicted {request.optical_coupling} passes with "
                "synchronous linearly implicit trapezoidal E update"
            )
        ),
        "material_response": request.material_response.model,
        "material_response_validation": (
            "validated"
        ),
    }
    if request.scattering is not None:
        diagnostics["canonical_scattering"] = canonical_scattering_provenance(
            request.scattering,
            z_length_um=request.grid.z_length_um,
            Nx=grid.Nx,
            Ny=grid.Ny,
            x_aperture_um=request.grid.x_aperture_um,
            y_aperture_um=request.grid.y_aperture_um,
            real_dtype=grid.real_dtype,
            xp=grid.xp,
        )

    movie = encode_td_preview_movie(
        movie_frames,
        material_frames=material_movie_frames,
        material_metadata={"quantity": "E", "label": "Reduced material E",
                           "material_plane_index": grid.Nz // 2},
        frame_indices=movie_frame_indices,
        material_times=movie_times,
        original_grid=grid.summary(),
        original_cadence=float(request.solver.dt_normalized),
    )
    extra_movies.attach(movie.metadata)
    if movie.warning is not None:
        diagnostics["td_preview_warning"] = movie.warning

    return PRRunResult(
        A_initial=A0_host,
        A_final=np.asarray(asnumpy(A_final)).copy(),
        E_initial=E_initial_host,
        E_final=E_final_host,
        source_intensity_stack=source_stack_host,
        power_initial=normalized_power(A0, grid),
        power_final=normalized_power(A_final, grid),
        completed_steps=completed_steps,
        time_normalized=current_time,
        grid_summary=grid.summary(),
        launch_summary={
            **launch.summary(),
            "refractive_index": float(request.material.refractive_index),
        },
        status=status,
        requested_steps=requested_steps,
        checkpoint=checkpoint,
        diagnostics=diagnostics,
        material_response_summary={
            "model": request.material_response.model,
            "software_evidence": (
                "validated"
            ),
            "integrator": (
                request.solver.integrator
            ),
        },
        td_scalar_history=tuple(td_scalar_history),
        td_preview_movie=movie.data,
        td_preview_movie_metadata=movie.metadata,
    )


def continue_pr_timedependent(
    request: PRRunRequest,
    checkpoint: PRTimeDependentCheckpoint,
    additional_steps: int,
    *,
    cancellation_token: CancellationToken | None = None,
    progress_callback: ProgressCallback | None = None,
    live_preview_policy: PRLivePreviewPolicy | None = None,
) -> PRRunResult:
    """Continue a compatible accepted PR state for additional material steps."""

    resolved_additional_steps = int(additional_steps)
    if (
        isinstance(additional_steps, bool)
        or resolved_additional_steps != additional_steps
        or resolved_additional_steps < 0
    ):
        raise ValueError("additional_steps must be a nonnegative integer")
    validate_pr_continuation(request, checkpoint)
    if request.material.normalization_identity != "pr_channel_peak_reference_v1" and request.initial_A is not None:
        raise ValueError("physical TD prepared initial_A requires an explicit physical scale; use the physical launch configuration")
    continuation_request = replace(
        request,
        solver=replace(request.solver, Nt=resolved_additional_steps),
        # Physical launches must retain beam-power/irradiance authority.
        # A0 is the fixed launch, not an evolving optical checkpoint state.
        initial_A=(np.asarray(checkpoint.A0).copy()
                   if request.material.normalization_identity == "pr_channel_peak_reference_v1"
                   else None),
        initial_E=np.asarray(checkpoint.E_current).copy(),
    )
    return run_pr_timedependent(
        continuation_request,
        cancellation_token=cancellation_token,
        progress_callback=progress_callback,
        live_preview_policy=live_preview_policy,
        _completed_steps_offset=int(checkpoint.completed_steps),
        _requested_steps_total=(
            int(checkpoint.completed_steps) + resolved_additional_steps
        ),
        _cumulative_start_time=float(checkpoint.time_normalized),
        _checkpoint_request=checkpoint.request,
        _origin_E=checkpoint.E_initial,
    )


__all__ = ["continue_pr_timedependent", "run_pr_timedependent"]
