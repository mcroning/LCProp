"""Installed PR package resources."""
