"""Compatibility alias for the canonical LC physics panel."""

from importlib import import_module as _import_module
import sys as _sys

_canonical = _import_module("lcprop.lc.gui.panels.physics_panel")
_sys.modules[__name__] = _canonical
